#include<conio.h>
#include<iostream>
#include<time.h>
using namespace std;


int main()
{
	int a[20][20], b[20][20], c[20][20];
	int x, y, i, j, m, n, num1, num2;

	srand(time(NULL)); // for generating the random number

	cout << "\nPlease Enter the number of rows and columns for Matrix A:\n\n";
	cin >> x >> y;

	// x denotes number rows in matrix A
	// y denotes number columns in matrix A

	cout << "\n\nRandom elements for Matrix A :\n\n";
	for (i = 0; i < x; i++)
	{
		for (j = 0; j < y; j++)
		{
			num1 = (rand() % 10);


			a[i][j] = num1;
			cout << num1 << endl;
		}
		cout << "\n";
	}
	cout << "\n\nMatrix A :\n\n";
	for (i = 0; i < x; i++)
	{
		for (j = 0; j < y; j++)
		{
			cout << "\t" << a[i][j];
		}
		cout << "\n\n";
	}
	cout << "\n-----------------------------------------------------------\n";
	cout << "\nEnter the number of rows and columns for Matrix B:\n\n";
	cin >> m >> n;
	// m denotes number rows in matrix B
	// n denotes number columns in matrix B

	cout << "\nElemets for random matrix B are \n\n";
	for (i = 0; i < m; i++)
	{
		for (j = 0; j < n; j++)
		{
			num2 = (rand() % 10);
			b[i][j] = num2;
			cout << num2 << endl;

		}
		cout << "\n";
	}
	cout << "\n\nMatrix B :\n\n";
	for (i = 0; i < m; i++)
	{
		for (j = 0; j < n; j++)
		{
			cout << "\t" << b[i][j];
		}
		cout << "\n\n";
	}

	if (y == m)
	{
		for (i = 0; i < x; i++)
		{
			for (j = 0; j < n; j++)
			{
				c[i][j] = 0;

				for (int k = 0; k < m; k++)
				{
					c[i][j] = c[i][j] + a[i][k] * b[k][j];
				}
			}
		}
		cout
			<< "\n-----------------------------------------------------------\n";
		cout << "\n\nMultiplication of Matrix A and Matrix B :\n\n";
		for (i = 0; i < x; i++)
		{
			for (j = 0; j < n; j++)
			{
				cout << "\t" << c[i][j];
			}
			cout << "\n\n";
		}
	}
	else
	{
		cout << "\n\nMultiplication is not possible";
	}
	getchar();
	getchar();

	return 0;
}
